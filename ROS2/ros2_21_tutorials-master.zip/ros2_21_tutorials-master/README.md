# ROS2入门21讲 · 古月

- 课程视频：[https://class.guyuehome.com/detail/p_628f4288e4b01c509ab5bc7a/6](https://class.guyuehome.com/detail/p_628f4288e4b01c509ab5bc7a/6)
- 图文教程：[https://book.guyuehome.com/](https://book.guyuehome.com/)
- 课程问答：[https://www.guyuehome.com/Bubble/circleDetail/id/90/](https://www.guyuehome.com/Bubble/circleDetail/id/90/)
- 博客泡圈：[https://www.guyuehome.com/](https://www.guyuehome.com/)

![课程大纲](docs/课程大纲.png)

![交流群](docs/交流群.png)
