#include "print.h"

int main() {
    print();
    old_print();
    return 0;
}