struct A {
    void set(int val);
    int get();

  private:
    int f;
};