#include "a.h"

void A::set(int val) { f = val; }

int A::get() { return f; }