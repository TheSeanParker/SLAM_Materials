#include <b.h>

int main() {
    f();
    return 0;
}