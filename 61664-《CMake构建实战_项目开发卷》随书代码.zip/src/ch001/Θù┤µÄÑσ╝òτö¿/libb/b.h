#include <a.h>

A f();