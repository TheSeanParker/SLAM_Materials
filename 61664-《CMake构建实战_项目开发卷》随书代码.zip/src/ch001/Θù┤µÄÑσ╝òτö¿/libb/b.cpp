#include "b.h"
#include <cstdio>

A f() {
    A a;
    a.set(10);
    return a;
}