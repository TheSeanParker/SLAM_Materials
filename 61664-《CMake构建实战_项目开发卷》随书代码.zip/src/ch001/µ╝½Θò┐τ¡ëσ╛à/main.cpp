﻿#include <iostream>

extern int fib25;

int main() {
    std::cout << "斐波那契数列第25项为：" << fib25 << std::endl;
    return 0;
}