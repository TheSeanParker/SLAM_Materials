#include <stdio.h>

int x = 1;

void a() { printf("&x: %llx\n", (unsigned long long)&x); }