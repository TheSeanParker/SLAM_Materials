#include "b.h"
#include <a.h>
#include <cstdio>

void f() {
    A a;
    a.set(10);
    printf("%d\n", a.get());
}