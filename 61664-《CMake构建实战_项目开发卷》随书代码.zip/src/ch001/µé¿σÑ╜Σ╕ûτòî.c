﻿#include <stdio.h>
int main() {
    printf("您好，世界！\n");
    return 0;
}