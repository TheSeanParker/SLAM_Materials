﻿#include <iostream>

extern int fib25;

int main() {
    std::cout << "The 25th item of Fibonacci Sequence is：" << fib25
              << std::endl;
    return 0;
}