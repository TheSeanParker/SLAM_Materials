void a();
void b();