#include <stdio.h>

void b() { printf("b\n"); }