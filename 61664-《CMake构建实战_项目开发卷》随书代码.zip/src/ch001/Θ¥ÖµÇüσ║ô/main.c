#include "libab.h"
#include <stdio.h>

int main() {
    a();
    b();
    return 0;
}