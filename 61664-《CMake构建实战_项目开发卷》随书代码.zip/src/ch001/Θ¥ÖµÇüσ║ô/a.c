#include <stdio.h>

void a() { printf("a\n"); }