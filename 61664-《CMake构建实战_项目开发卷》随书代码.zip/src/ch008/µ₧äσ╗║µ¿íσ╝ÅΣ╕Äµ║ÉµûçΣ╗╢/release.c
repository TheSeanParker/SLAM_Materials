#include <stdio.h>

int main() {
    printf("Release\n");
    return 0;
}