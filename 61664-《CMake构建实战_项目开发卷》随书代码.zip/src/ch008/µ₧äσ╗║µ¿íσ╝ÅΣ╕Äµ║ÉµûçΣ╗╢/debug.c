#include <stdio.h>

int main() {
    printf("Debug\n");
    return 0;
}