#include <stdio.h>

int main() {
    printf("%d %d\n", A, B); // 输出1 1
    return 0;
}