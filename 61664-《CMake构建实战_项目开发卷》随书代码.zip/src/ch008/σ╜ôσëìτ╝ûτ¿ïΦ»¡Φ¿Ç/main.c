extern void print_c();
extern void print_cpp();

int main() {
    print_c();
    print_cpp();
    return 0;
}