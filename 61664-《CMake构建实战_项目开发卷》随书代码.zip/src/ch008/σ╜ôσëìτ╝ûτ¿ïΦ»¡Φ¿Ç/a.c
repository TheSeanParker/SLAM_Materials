#include <stdio.h>

void print_c() { printf("%d\n", A); }