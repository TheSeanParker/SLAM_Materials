#include <iostream>

extern "C" void print_cpp() { std::cout << A << std::endl; }