#include <stdio.h>

int main() {
    printf("VERSION: %s\n", VERSION);
    return 0;
}