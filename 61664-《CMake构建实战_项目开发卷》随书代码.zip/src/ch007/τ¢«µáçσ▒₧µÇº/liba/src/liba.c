#include <liba.h>

const char *fa() { return "liba"; }