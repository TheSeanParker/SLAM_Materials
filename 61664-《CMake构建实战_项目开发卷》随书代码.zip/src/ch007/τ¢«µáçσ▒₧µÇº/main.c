#include <f.h>
#include <liba.h>
#include <stdio.h>

int main() {
    printf("fa: %s\n", fa());
    printf("f: %s\n", f());
    return 0;
}