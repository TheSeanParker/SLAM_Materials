#include <stdio.h>

int fa(int a, int b);
int fb(int a, int b);

int main() {
    printf("%d %d\n", fa(1, 2), fb(3, 1));
    return 0;
}