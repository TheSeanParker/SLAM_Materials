#include <stdio.h>

int main() {
    printf("DIR: %s\n", DIR);
    return 0;
}