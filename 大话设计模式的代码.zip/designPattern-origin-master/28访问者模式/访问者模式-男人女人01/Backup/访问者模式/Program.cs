﻿using System;
using System.Collections.Generic;
using System.Text;

namespace 访问者模式
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("男人成功时，背后多半有一个伟大的女人。");
            Console.WriteLine("女人成功时，背后大多有一个不成功的男人。");
            Console.WriteLine("男人失败时，闷头喝酒，谁也不用劝。");
            Console.WriteLine("女人失败时，眼泪汪汪，谁也劝不了。");
            Console.WriteLine("男人恋爱时，凡事不懂也要装懂。");
            Console.WriteLine("女人恋爱时，遇事懂也装作不懂。");


            Console.Read();
        }
    }

}
