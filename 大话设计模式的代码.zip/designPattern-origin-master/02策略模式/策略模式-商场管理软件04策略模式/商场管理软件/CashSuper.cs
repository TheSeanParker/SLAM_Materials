﻿using System;
using System.Collections.Generic;
using System.Text;

namespace 商场管理软件
{
    abstract class CashSuper
    {
        public abstract double acceptCash(double money);
    }
}
