﻿using System;
using System.Collections.Generic;
using System.Text;

namespace 动物练习
{
    interface IChange
    {
        string ChangeThing(string thing);
    }
}
