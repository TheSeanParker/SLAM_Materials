template<class T = double>
void foo()
{
	T t;
}

int main()
{
	foo();
}
