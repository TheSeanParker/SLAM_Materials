enum Color3 {};

int main()
{
	Color3 c{ 7 };
}
