[[deprecated]] void foo() {}
class [[deprecated]] X {};
int main()
{
	X x;
	foo();
}
