template<class T = double, class U, class R = double>
void foo(U u) {}

int main()
{
	foo(5);
}
