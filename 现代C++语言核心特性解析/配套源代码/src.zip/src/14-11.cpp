enum class Color1 : char {};

int main()
{
	Color1 c{ 7.11 };
}
